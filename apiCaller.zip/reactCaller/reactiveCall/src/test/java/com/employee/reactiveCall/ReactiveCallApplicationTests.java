package com.employee.reactiveCall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveCallApplicationTests {

	@Test
	void contextLoads() {
	}

}
