package com.reactiveCaller.reactCaller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactCallerApplicationTests {

	@Test
	void contextLoads() {
	}

}
