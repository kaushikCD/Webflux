package com.reactiveCaller.reactCaller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactCallerApplication {
	public static void main(String[] args) {
		SpringApplication.run(ReactCallerApplication.class, args);
	}
}
